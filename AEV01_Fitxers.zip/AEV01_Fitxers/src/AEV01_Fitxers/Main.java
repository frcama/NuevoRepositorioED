package AEV01_Fitxers;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		
		String ruta = null;
		String rutacarpeta;
		String rutafichero;
		String eliminar;
		
        System.out.println("Selecciona una operación:");
        System.out.println("1. Mostrar información");
        System.out.println("2. Crear carpeta");
        System.out.println("3. Crear fichero");
        System.out.println("4. Eliminar fichero o carpeta");
        System.out.println("5. Renombrar fichero o carpeta");
        
        int opcion = teclado.nextInt();
        teclado.nextLine(); 

        switch (opcion) {
            case 1:
                System.out.print("Introduce la ruta: ");
                ruta = teclado.nextLine();
                File fichero = new File(ruta);
                System.out.println(getInformacion(fichero));
                break;

            case 2:
            	System.out.print("Introduce la ruta donde vas a  crear la carpeta: ");
                String rutaCarpeta = teclado.nextLine();
                creaCarpeta(rutaCarpeta);
                break;
                
                

            case 3:
            	System.out.print("Introduce la ruta donde vas a  crear el fichero: ");
                String rutaFitxer = teclado.nextLine();
                crearfichero(rutaFitxer);
                break;

            case 4:
            	System.out.print("Introduce la ruta del fichero o carpeta a eliminar: ");
                String rutaEliminar = teclado.nextLine();
                elimina(rutaEliminar);
                break;

            case 5:
            	System.out.print("Introduce la ruta actual del fichero o carpeta: ");
                String rutaActual = teclado.nextLine();
                System.out.print("Introduce el nuevo nombre del fichero o carpeta: ");
                String nouNom = teclado.nextLine();
                renomena(rutaActual, nouNom);
                break;
                

            default:
                System.out.println("Opcion no valida.");
        }

      
    }
	 public static String getInformacion(File fichero) {
	        StringBuilder info = new StringBuilder();
	        
	        if (!fichero.exists()) {
	            return "Error: El fichero o directorio no existe.";
	        }

	        if (!fichero.canRead()) {
	            return "Error: No tienes permisos.";
	        }

	        info.append("Nombre: ").append(fichero.getName()).append("\n");
	        info.append("Ubicacion: ").append(fichero.getAbsolutePath()).append("\n");
	        info.append("Última modificacion: ").append(new java.util.Date(fichero.lastModified())).append("\n");
	        info.append("Oculto: ").append(fichero.isHidden() ? "Sí" : "No").append("\n");

	        if (fichero.isFile()) {
	            info.append("Tipos: Fichero\n");
	            info.append("Grandària: ").append(fichero.length()).append(" bytes\n");
	        } else if (fichero.isDirectory()) {
	            String[] elements = fichero.list();
	            if (elements != null) {
	                info.append("Tipo: Directorio\n");
	                info.append("Elementos: ").append(elements.length).append("\n");
	            } else {
	                info.append("Elementos: Error");
	            }
	            info.append("Espacio libre: ").append(fichero.getFreeSpace()).append(" bytes\n");
	            info.append("Espacio disponible: ").append(fichero.getUsableSpace()).append(" bytes\n");
	            info.append("Espacio total: ").append(fichero.getTotalSpace()).append(" bytes\n");
	        }

	        return info.toString();
	    }
	 
	 public static void creaCarpeta(String rutaCarpeta) {
	        File carpeta = new File(rutaCarpeta);
	        if (carpeta.exists()) {
	            System.out.println("Error: La carpeta ja existeix.");
	        } else if (carpeta.mkdirs()) {
	            System.out.println("Carpeta creada correctament.");
	        } else {
	            System.out.println("Error: No s'ha pogut crear la carpeta.");
	        }
	 }
	 public static void crearfichero(String rutafichero) {
	        File fitxer = new File(rutafichero);
	        if (fitxer.exists()) {
	            System.out.println("Error: El fitxer ja existeix.");
	        } else {
	            try {
	                if (fitxer.createNewFile()) {
	                    System.out.println("Fitxer creat correctament.");
	                } else {
	                    System.out.println("Error: No s'ha pogut crear el fitxer.");
	                }
	            } catch (IOException e) {
	                System.out.println("Error: " + e.getMessage());
	            }
	        }
	    }
	    
	 public static void elimina(String ruta) {
	        File fichero = new File(ruta);
	        if (!fichero.exists()) {
	            System.out.println("Error: El fitxer o carpeta no existeix.");
	        } else if (fichero.delete()) {
	            System.out.println("El fitxer o carpeta s'ha eliminat correctament.");
	        } else {
	            System.out.println("Error: No s'ha pogut eliminar el fitxer o carpeta.");
	        }
	    }
	 public static void renomena(String rutaActual, String nuevoNombre) {
	        File fitxerActual = new File(rutaActual);
	        File fitxerNou = new File(fitxerActual.getParent(), nuevoNombre);
	        if (!fitxerActual.exists()) {
	            System.out.println("Error: El fitxer o carpeta no existeix.");
	        } else if (fitxerActual.renameTo(fitxerNou)) {
	            System.out.println("El fitxer o carpeta s'ha renombrat correctament.");
	        } else {
	            System.out.println("Error: No s'ha pogut renombrar el fitxer o carpeta.");
	        }
	    }


		
		
	


}
	

